# Local Evidence Note (REAL_LOCAL_RUN)
- objective: x; rm -rf / && echo pwned
- exact commit: 0381aea0e75e8b492138d6da0a4117e182f3bd62
- tests: 30/30 (failures: 0)
- decision: INTERNAL_DEMO_ONLY (never SHIP)
- limitations: REAL_LOCAL_RUN of a self-owned target; not provider-backed; not production/secure/compliant

This is an internal-demo-grade local evidence package. Not production/secure/compliant.