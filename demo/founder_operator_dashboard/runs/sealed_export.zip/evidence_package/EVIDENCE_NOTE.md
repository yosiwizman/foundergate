# Local Evidence Note (REAL_LOCAL_RUN)
- objective: $(touch /tmp/pwned_advisor) `id`
- exact commit: 47e77daef9e996acd96d32858e8f0efba0066d1a
- tests: 30/30 (failures: 0)
- decision: INTERNAL_DEMO_ONLY (never SHIP)
- limitations: REAL_LOCAL_RUN of a self-owned target; not provider-backed; not production/secure/compliant

This is an internal-demo-grade local evidence package. Not production/secure/compliant.